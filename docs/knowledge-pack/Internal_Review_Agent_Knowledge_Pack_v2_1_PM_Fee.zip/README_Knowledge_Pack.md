# Internal Review Agent Knowledge Pack v2.1 - PM Fee

This controlled pack adds Property Management Fee Review to the General Ledger-enabled Internal Review Agent.

Key controls: hardcoded adjustment-to-GL tie, method-specific double-count prevention, OneSite/Entrada/Yardi normalization, 150% trailing-average revenue spike warning, and fee-to-payable tie.

Upload together and archive superseded PM Fee knowledge files. Rule Library controls when wording conflicts.
